public class ImprimindoNumeros {
    public static void main(String[] args) {
        int i = 1;
        while (i <= 20){
            if (i%5==0){
                System.out.println(i);
                i++;
            }
            else{
                System.out.print(i+"\t");
                i++;
            }
        }

    }
}